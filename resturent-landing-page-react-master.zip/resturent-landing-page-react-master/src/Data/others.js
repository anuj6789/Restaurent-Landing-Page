export const others = [
  {
    id: 1,
    name: "OREO",
    price: 150,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-oreo-mcflurry-snack.jpg?$Product_Desktop$",
  },
  {
    id: 2,
    name: "Vanilla Cone",
    price: 100,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-Vanilla-Reduced-Fat-Ice-Cream-Cone.jpg?$Product_Desktop$",
  },
  {
    id: 3,
    name: "french fry",
    price: 80,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-fries-small.jpg?$Product_Desktop$",
  },
  {
    id: 4,
    name: "Cinnamon Roll",
    price: 50,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-cinnamon-roll.jpg?$Product_Desktop$",
  },
];
