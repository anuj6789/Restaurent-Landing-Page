export const combo = [
  {
    id: 1,
    name: "Cheeseburger Combo Meal",
    price: 700,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/assets/meal/desktop/h-mcdonalds-2-Cheeseburger-Extra-Value-Meals.jpg?$Product_Desktop$",
  },
  {
    id: 2,
    name: "Cheese Meal",
    price: 800,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/assets/meal/desktop/h-mcdonalds-Quarter-Pounder-with-Cheese-Extra-Value-Meals.jpg?$Product_Desktop$",
  },
  {
    id: 3,
    name: "Sandwich Combo Meal",
    price: 750,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/assets/meal/desktop/h-crispy-chicken-sandwich-meal.jpg?$Product_Desktop$",
  },
  {
    id: 4,
    name: "10 piece Chicken",
    price: 500,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/assets/meal/desktop/h-mcdonalds-Chicken-McNuggets-10-piece-Extra-Value-Meals.jpg?$Product_Desktop$",
  },
];
