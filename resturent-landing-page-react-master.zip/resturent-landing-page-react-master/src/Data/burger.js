export const burgers = [
  {
    id: 1,
    name: "Big Mac",
    price: 300,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-Big-Mac.jpg?$Product_Desktop$",
  },
  {
    id: 2,
    name: "Quarter Pounder",
    price: 400,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-Quarter-Pounder-with-Cheese.jpg?$Product_Desktop$",
  },
  {
    id: 3,
    name: "Cheeseburger",
    price: 380,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-Cheeseburger.jpg?$Product_Desktop$",
  },
  {
    id: 4,
    name: "Hamburger",
    price: 480,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-Hamburger.jpg?$Product_Desktop$",
  },
  {
    id: 5,
    name: "Cheese Bacon",
    price: 450,
    imageUrl:
      "https://www.mcdonalds.com/is/image/content/dam/usa/nfl/nutrition/items/hero/desktop/t-mcdonalds-qpc-bacon.jpg?$Product_Desktop$",
  },
];
