export const chicken = [
  {
    id: 1,
    name: "6 PC Boneless Strips",
    price: 700,
    imageUrl:
      "https://images.unsplash.com/photo-1610057099431-d73a1c9d2f2f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80",
  },
  {
    id: 2,
    name: "4 Pcs Hot & Crispy Chicken",
    price: 600,
    imageUrl:
      "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
  },
  {
    id: 3,
    name: "4PC Smoky Red Chicken",
    price: 600,
    imageUrl:
      "https://images.unsplash.com/photo-1556913241-def7c10b821d?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1279&q=80",
  },
  {
    id: 4,
    name: "6 PC Hot Wings",
    price: 400,
    imageUrl:
      "https://images.unsplash.com/photo-1567620832903-9fc6debc209f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=714&q=80",
  },
];
